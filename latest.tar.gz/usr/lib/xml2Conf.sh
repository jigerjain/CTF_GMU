#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/lib"
XML2_LIBS="-lxml2 -lz   -lm "
XML2_INCLUDEDIR="-I/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.2"

