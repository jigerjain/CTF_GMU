
<html lang="en">
<head>
<head>
<meta charset="utf-8">
<title>CC | Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="Title" content="Mason Competitive Cyber">
<meta name="Keywords" content="gmu,cyber,mason,cybersecurity,ctf,club,org">
<meta name="Description" content="Mason Competitive Cyber is a cybersecurity organization at George Mason University in Fairfax, Virginia that meets weekly and specializes in competing.">
<meta name="Subject" content="Cybersecurity">
<meta name="Language" content="English">
<meta property="og:image" content="https://competitivecyber.club/images/transparent.png" />
<link href="/scripts/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/scripts/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
<link rel="stylesheet" href="/scripts/fontawesome/css/font-awesome.min.css">
<link href="/scripts/carousel/style.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Palatino+Linotype" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css">
<link href="/styles/custom.css?ver=fixbg" rel="stylesheet" type="text/css" />
<link rel="icon" href="/images/mcc.ico">
<script src="/scripts/jquery.min.js" type="text/javascript"></script>
<script src="/scripts/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/scripts/default.js?ver=5.1.2" type="text/javascript"></script>
<script src="/scripts/carousel/jquery.carouFredSel-6.2.0-packed.js" type="text/javascript"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},<?php require 'app/.functions.php' ?>i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-106121097-1', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body id="pageBody">
<div id="decorative2">
<div class="container-fluid">
<div class="divPanel topArea notop nobottom">
<div class="row-fluid">
<div class="span12">
<div id="divLogo" class="pull-left">
<a href="/" id="divSiteTitle"></a><br />
<a href="/" id="divTagLine">GMU's Cybersecurity Organization</a>
</div>
<div id="divMenuRight" class="pull-right">
<div class="navbar">
<button type="button" class="btn btn-navbar-highlight btn-large btn-primary" data-toggle="collapse" data-target=".nav-collapse">
NAVIGATION <span class="icon-chevron-down icon-white"></span>
</button>
<div class="nav-collapse collapse">
<ul class="nav nav-pills ddmenu">
<li class="dropdown"><a href="/">Home</a></li>
<li class="dropdown">
<li class="dropdown"><a href="/videos/">Videos</a></li>
<li class="dropdown"><a href="/meeting">Calendar</a></li>
<li class="dropdown"><a href="/articles/">Articles</a></li>
<li class="dropdown"><a href="/join/">Join</a></li>
<li class="dropdown"><a href="/gallery/">Pics</a></li>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script>
var i = 0;
var txt = 'Mason Competitive Cyber';
var speed = 50;

function typeWriter() {
  if (i < txt.length) {
    document.getElementById("divSiteTitle").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}
typeWriter();
</script>
<style>
.quotes {display: none;}
</style>
<div id="decorative1" style="position:relative">
<div class="container">
<div class="divPanel headerArea">
<div class="row-fluid">
<div class="span12">
<div id="headerSeparator"></div>
<div id="divHeaderText" class="page-content">
<div id="maintitle">Mason Competitive Cyber</div><br />
<div id="subtitle">
<div class="quotes">Learning Cybersecurity Through Competition</div>
<div class="quotes">Solving Silly Little Puzzles Since 2016</div>
<div class="quotes">Everyone's Favorite Shell Popping Patriots</div>
<div class="quotes">Learn How To Root Your Toaster</div>
<div class="quotes">Who Needs Parties When You Can Have Binary Exploitation</div>
<div class="quotes">The Binary Exploitation and Forensic Appreciation Society</div>
<div class="quotes">Professional Development, But Fun</div>
<div class="quotes">If You Use Radare2, This Club's For You</div>
<div class="quotes">If You Like Battelle Employees, You'll Love Our Members</div>
<div class="quotes">@dhaynes pls</div>
</div><br /><br />
<div id="meetingbutton"><a class="btn btn-large btn-primary" href="/meeting/">Key Details</a></div>
</div>
<div id="headerSeparator2"></div>
</div>
</div>
</div>
</div>
</div>
<div id="contentOuterSeparator"></div>
</head>
<body>
<div class="container">
<style>
    .descript {
        font-size: 14;
    }
    .fineprint {
        font-size: 12;
        font-style: italic;
    }
</style>
<div style="background-color: 006633; text-align: center; color: white">
<br>
Welcome #Mason2022! Make sure to join the Slack or mailing list below,<br>get to know other ways to get involved under "Join" on the top right, and check out a meeting under the "Meetings" page!
<br><br>
</div>
<div class="container">
<div class="divPanel page-content">
<div class="row-fluid">
<div class="span1"></div>
<div class="span10" style="font-size: 14px;" id="divMain">
<div class="lead">
<img class="logo" src="images/transparent_minimal.png" width="10%" height="2em"><br>
<p style="color: grey; font-size: 0.75em"><i>Logo Credit: Katie Gilder</i></p>
<h2>Welcome to Mason CC</h2>
<p style="font-size: 14px;">Mason Competitive Cyber is the sole cybersecurity organization at GMU.
<br><br>
We don't require any prior experience from our members, but we try to accommodate all audiences of technical ability and some level of technicial proficiency (not in cybersecurity specifically) will dramatically benefit members. We cover both advanced and more fundamental topics in meetings and compete outside of meetings, coordinated via our chat.
<br>Our next Gold Track meeting is at <b><span id="location"></span> on <span id="date"></span> from <span id="start"></span> to <span id="finish"></span></a>.</b> Green Track will meet at <b><span id="advloc"></span></b> at the same date and time. <span id="signup"></span>
<br /><h3>If you otherwise need to contact us, email us at <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="046965776b6a6767446369712a616071">[email&#160;protected]</a></h3>
<br>
<br>
</p>
<hr>
<h2>Want to Get Involved? Join our Chat!</h2>
<p>If you are a George Mason student, enter your NetID below and you should get an email in your inbox!</p>
<div class="form-group">
<div class="input-append">
<form id="joinup" onsubmit="javascript:joinSlack();return false;">
<input class="span2" id="netid" style="text-align: right;" type="text">
<span class="add-on">@gmu.edu</span>
</div><br>
<button type="button" id="chatjoin" onclick="javascript:joinSlack();" id="button" class="btn btn-primary btn-large">Join our Slack</button>
</div>
<br><p><div id="response"></div>
<h2>Hate Slack? Join our mailing list!</h2>
<p class="descript">If you hate Slack but still want notifications, you can subscribe to a list that notifies you if meetings are coming up or competitions are being organized.</p><br />
<p class="fineprint">The mailing list is not a replacement for Slack. If you want to get further involved in CC, including competing, activity in Slack is needed. Repeated requests for information will only get you referred to the appropriate source.</p>
</form>
<div class="form-group">
<form id="joinemail" action="https://club.us18.list-manage.com/subscribe/post" method="POST">
<input type="hidden" name="u" value="f74cc9ffc33dcd2cb19db29b6">
<input type="hidden" name="id" value="3e14d1a163">
<input type="hidden" name="orig-lang" value="1">
Email: <input type="email" name="MERGE0" id="MERGE0" class="span2" placeholder="test@example.com" style="text-align: right;"><br />
First: <input type="text" name="MERGE1" id="MERGE1" class="span3" value=""><br />
Last: <input type="text" name="MERGE2" id="MERGE2" class="span3" value="">
<br>
<button type="submit" id="clubjoin" id="button" class="btn btn-primary btn-large">Subscribe to list</button>
</div>
</div>
<div class="span1"></div>
</div><br>
<div class="row-fluid">
<div class="span2"></div>
<div class="span8" style="text-align: center">
<hr>
<h3>Club Updates</h3>
</div>
<div class="span2"></div>
</div>
<br />
<div class="row-fluid">
<div class="span3">
<p>
<img src="/images/pandatoday.jpeg" class="img-polaroid" style="float: right; padding-top: 1%; max-width: 15em; padding-bottom: 1%" align="right">
</p>
</div>
<div class="span9">
<h3>Mason CC to have Panda Express Fundraiser, August 31</h3>
<p>For more information, including the <b>flyer required to make your payment count</b>, see <a href="https://competitivecyber.club/events/panda/">our event article</a>.<br><br>
</p>
</div>
</div>
<br /><br />
<div class="row-fluid">
 <div class="span3">
<p>
<img src="/images/report.jpg" class="img-polaroid" style="float: right; max-width: 15em; padding-bottom: 1%" align="right">
</p>
</div>
<div class="span9">
<h3>Mason CC Releases AY17-18 Report</h3>
<p>Mason CC, ahead of their last meeting and CryptoParty, released a report <a href="docs/AY1718_CCReport.pdf">here</a> <b>(LARGE PDF WARNING: 77MB)</b> on our activities of our last year.<br><br>
</p>
</div>
</div>
<br /><br />
<div class="row-fluid">
<div class="span3">
<p>
<img src="https://media.azpm.org/master/image/2017/9/29/spot/dhslogo.jpg" class="img-polaroid" style="float: right; padding-top: 1%; max-width: 15em; padding-bottom: 1%" align="right">
</p>
</div>
<div class="span9">
<h3>Department of Homeland Security to Visit</h3>
<p>Mason CC is happy to welcome William Burke IV to Mason CC to discuss red teaming in the context of his work at the Department of Homeland Security. While registration has already locked, for more information feel free to see <a href="https://competitivecyber.club/articles/dhs/">our signup article</a>.<br><br>
</p>
</div>
</div>
<a href="/oldnews/">Older News</a><br><br>
<hr style="border-style: inset; margin-top: 25px; border-width: 1px;">
<h1 style="text-align: center;">Proud Sponsors</h1>
<p style="text-align: center;">Thank you to the following companies for providing Mason CC with major support and/or donations:</p><br><br>
<div class="row-fluid">
<div class="span3">
</div>
<div class="span6" style="text-align: center; ">
<a href="https://careers.crypsisgroup.com"><img src="images/crypsis.jpg" style="width: 75%"></a><br>
</div>
<div class="span3"></div>
</div>
<div class="row-fluid">
<div class="span2"></div>
<div class="span8"><br>
The Crypsis Group, frequently referred to as <i>Crypsis</i>, is a company headquartered in McLean, VA that largely does digital forensics and incident response. Crypsis employs multiple CC members and is looking to hire more through their internship announced at the same time of the sponsorship. Crypsis also has spoken at CC, provided CC with pizza at a meeting, funded CC to a generous extent, and has had their work be inspiration for the <i>Host Based Forensics</i> talk and <i>Love Your Logs</i> talks. In addition to internal contacts, members could see their <a href="https://careers.crypsisgroup.com">careers page</a> for internship and job opportunities.
</div>
<div class="span2">
</div>
</div>
<hr /><br />
<div class="row-fluid">
<div class="span3">
</div>
<div class="span6" style="text-align: center;>
                          <a href=" http: www.battelle.org "><img src="images/battelle.jpg" style="width: 75%"></a><br>
</div>
<div class="span3"></div>
</div>
<div class="row-fluid">
<div class="span2"></div>
<div class="span8"><br>Battelle was our first ask for sponsorship and when we called they answered. With about 6 members in advanced training being actively employed by Battelle at the time of the sponsorship, our club's always had a distinct interest in Battelle as a company. With the support of Battelle, Mason CC will be able to pay for shirts, potentially CCDC registration, and more to further our unity as an organization and further legitamize our mission. In addition to internal contacts, members could see their <a href="https://jobs.battelle.org/">careers page</a> for internship and job opportunities. Active competitors may also be interested in the <a href="https://battellecyberchallenge.org/">Battelle Cyber Challenge</a> that prioritizes candidates.</div>
<div class="span2"></div>
</div><br />
<hr />
<p style="text-align: center;">In addition, thank you to <a href="https://grimm-co.com">GRIMM Co.</a> for partnering with us to provide us a variety of challenges and a talk to keep our members entertained.<br></a>
<hr style="margin:45px 0 35px" />
<div class="row-fluid">

</div>
<div class="row-fluid">
<div class="span2"></div>
<div class="span8 sidebar">
<div class="sidebox" style="margin-top: 0px">
<h3 class="sidebox-title">Upcoming Competitions</h3>
<p><div id="comps"></div></p>
</div>
<br />
</div>
<div class="span2"></div>
<br>
</div><br><br>
</div>
</div>
<div id="footerInnerSeparator"></div>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
    $.getJSON('/competition/json?nocache=' + (new Date()).getTime(), null, function(data) {
      console.log('JSON data loaded')
      console.log(data)
      entry = ""
      $.each(data["competitions"], function(i, item) {
      console.log('Iterating')
      console.log(Date.parse(item["startDate"] + ' ' + item["year"]))
      if ( Date.now() - Date.parse(item["startDate"] +  ' '  +  item["year"]) < 0) {
          console.log(Date.now() - Date.parse(item["startDate"] +  item["year"]))
          if (item["startDate"] == item["endDate"]){
          entry = entry + "<br>" + item["name"] + ' at ' + item["location"] + ' on ' + item["startDate"] + ', ' + item["startTime"] + ' to ' + item["endTime"] + '|' + '<a href="' + item["moreInfo"] + '">More info</a><br>'
          } else {
            entry = entry + "<br>" + item["name"] + ' at ' + item["location"] + ' on ' + item["startDate"] + ', ' + item["startTime"] + ' to ' + item["endDate"] + ', ' + item["endTime"] + '|' + '<a href="' + item["moreInfo"] + '">More info</a><br>'
          }
          console.log(entry)
        }
      });
      $("#comps").html(entry)
    });
    $.getJSON('/meeting/json', null, function(data) {
      console.log('JSON data loaded')
      $.each(data["meetings"], function(i, item) {
      console.log('Iterating')
        time = item["to"]
        if (time.includes('pm')) {
          time = time.split('pm')[0]
          hour = time.split(':')[0]
          min = time.split(':')[1]
          hour = parseInt(hour) + 12
          time = hour + ":" + min
        } else {
          time = time.split('am')[0]
          hour = time.split(':')[0]
          min = time.split(':')[1]
          time = hour + ":" + min
        }
        if ( Date.now() - Date.parse(item["meetingDate"] +  ' ' +  item["year"] + ' ' + time) <= 0) {
          console.log(Date.now() - Date.parse(item["meetingDate"] +  ' ' + item["year"]))
          $("#location").html(item['location'])
          $("#start").html(item['from'])
          $("#finish").html(item['to'])
          $("#advloc ").html(item['advlocation'])
          $('#date').html(item['meetingDate'])
          if (item.hasOwnProperty('guestsignup')){
            data = '<span style="font-weight: bold; color: red"> Signup is enforced for this event, please visit <a href="' + item['guestsignup'] + '">the signup page</a> for more.</span>'
            $('#signup').html(data)
          }
          return false;
        } else {
          console.log(Date.now() - Date.parse(item["meetingDate"] +  ' ' + item["year"]))
        }
      });
    });

</script>
<script>

    // Set the date we're counting down to
var countDownDate = new Date("Nov 3, 2018 10:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();
    
    // Find the distance between now and the count down date
    var distance = countDownDate - now;
    
    // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    // Output the result in an element with id="demo"
    document.getElementById("maintitle").innerHTML = days + "d " + hours + "h "
    + minutes + "m " + seconds + "s ";
    
    // If the count down is over, write some text 
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("maintitle").innerHTML = "<a href='https://patriotctf.gmu.io'>pgatriotCTF Registration open</a>";
    }
}, 1000);
$("#meetingbutton").html('<a class="btn btn-large btn-primary" href="https://patriotctf.gmu.io">patriotCTF</a>')
pic = Math.floor(Math.random() * 28) + 1;
$("#decorative1").css("background-image","url(https://competitivecyber.club/rolodex/"+pic+".jpg)")
</script>
<script type="text/javascript">$('#list_photos').carouFredSel({ responsive: true, width: '100%', scroll: 2, items: {width: 320,visible: {min: 2, max: 6}} });</script>
</div>
<div id="footer">
<div id="footerOuterSeparator"></div>
</div>
<div id="divFooter" class="footerArea">
<div class="container">
<div class="divPanel">
<div class="row-fluid">
</div>
<br /><br />
<div class="row-fluid">
<div class="span12">
<p class="copyright">
Email: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="533e32203c3d303013343e267d363726">[email&#160;protected]</a><br />
Copyright © 2018 Mason Competitive Cyber.
</p>
<p class="social_bookmarks">
<a href="https://www.facebook.com/masoncompcyber"><i class="social "></i> Facebook</a>
<a href="https://www.instagram.com/masoncompcyber/"><i class="social "></i>Instagram</a>
<a href="https://twitter.com/masoncompcyber"><i class="social "></i> Twitter</a>
<a href="https://getconnected.gmu.edu/organization/masoncc/"><i class="social "></i> GetConnected</a>
<a href="https://masoncc.slack.com/"><i class="social "></i> Slack</a>
</p>
</div>
</div>
<br />
</div>
</div>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script></body>
</html>
